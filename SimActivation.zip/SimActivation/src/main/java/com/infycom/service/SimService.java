package com.infycom.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infycom.dto.SimOffersDTO;
import com.infycom.entity.SimDetails;
import com.infycom.entity.SimOffers;
import com.infycom.exceptions.NoSuchSimException;
import com.infycom.exceptions.SimAlreadyActiveException;
import com.infycom.repository.SimDetailsRepository;
import com.infycom.repository.SimOffersRepository;
@Service
public class SimService {
	@Autowired
	SimDetailsRepository simDetailsRepository;
	
	@Autowired
	SimOffersRepository simOffersRepository;
	
	public SimOffersDTO getOffer(String simNum1, String serviceNum1) throws SimAlreadyActiveException, NoSuchSimException {
		long simNum=Long.parseLong(simNum1);
		long serviceNum=Long.parseLong(serviceNum1);
		List<SimDetails> list_sim=simDetailsRepository.findAll();
		SimOffersDTO simOffersDTO=null;
		for(SimDetails sim:list_sim) {
			if(sim.getSimNumber()==simNum && sim.getServiceNumber()==serviceNum) {
				if(sim.getSimStatus().equals("active")) {
					throw new SimAlreadyActiveException();
				}
				List<SimOffers> list_offer=simOffersRepository.findAll();
				for (SimOffers simOfferTemp : list_offer) {
					if(sim.getSimId()==simOfferTemp.getSimId()) {
						simOffersDTO=SimOffersDTO.prepareDTO(simOfferTemp);
					}
				}
				
			}
		}
		if(simOffersDTO==null) {
			throw new NoSuchSimException();
		}
		else {
			return simOffersDTO;
		}	
	}
	
	String activateSim(int simId) {
		Optional<SimDetails> simDetailsOptional=simDetailsRepository.findById(simId);
		System.out.println(simId+" simID");
		try {
			SimDetails simDetails=simDetailsOptional.orElseThrow();
			simDetails.setSimStatus("active");
			simDetailsRepository.saveAndFlush(simDetails);
			return "SIM succussfully activated";
		}
		catch(NoSuchElementException ex) {
			return "SimDetails with given simId not present in SimDetails Table!";
		}
	}

}
