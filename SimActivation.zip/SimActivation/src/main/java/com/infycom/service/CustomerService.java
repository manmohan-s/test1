package com.infycom.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infycom.dto.CustomerAddressDTO;
import com.infycom.dto.CustomerDTO;
import com.infycom.dto.CustomerIdentityDTO;
import com.infycom.entity.Customer;
import com.infycom.entity.CustomerAddress;
import com.infycom.entity.CustomerIdentity;
import com.infycom.exceptions.InvalidEmailException;
import com.infycom.repository.CustomerAddressRepository;
import com.infycom.repository.CustomerIdentityRepository;
import com.infycom.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	@Autowired
	CustomerAddressRepository customerAddressRepository;
	
	@Autowired
	CustomerIdentityRepository customerIdentityRepository;
	
	@Autowired
	SimService simService;
	
	public String verifyBasicDetails(CustomerDTO customerDTO) {
		String email=customerDTO.getEmailAddress();
		String dob=customerDTO.getDateOfBirth();
		List<Customer> list_customer=customerRepository.findAll();
		for (Customer customer : list_customer) {
			if(customer.getEmailAddress().equals(email) && customer.getDateOfBirth().equals(dob)) {
				return "Successfully verified";
			}
		}
		return "No request placed for you";
	}

	public String verifyPersonalDetails(CustomerDTO customerDTO) throws InvalidEmailException {
		String error="";
		String fname=customerDTO.getFirstName();
		String lname=customerDTO.getLastName();
		if(fname==null) {
			error+="FirstName is required! ";
		}
		else {
			if(! fname.matches("[A-Za-z]{1,15}")){
				error+="FirstName should only be alphabets with length of 1-15 character! ";
			}
		}
		if(lname==null) {
			error+="LastName is required! ";
		}
		else {
			if(! lname.matches("[A-Za-z]{1,15}")){
				error+="LastName should only be alphabets with length of 1-15 character! ";
			}
		}
		
		if(error!="") {
			return error;
		}
		String email=customerDTO.getEmailAddress();
		List<Customer> list_customer=customerRepository.findAll();
		for (Customer customer : list_customer) {
			if(customer.getFirstName().equals(fname) && customer.getLastName().equals(lname)) {
				if(customer.getEmailAddress().equals(email)) {
					return "Successfully verified";
				}
				else {
					throw new InvalidEmailException();
				}
			}
		}
		return "No customer found for the provided details";
	}

	public String updateAdress(@Valid CustomerAddressDTO customerAddressDTO) {
		CustomerAddress customerAddress=CustomerAddressDTO.prepareEntity(customerAddressDTO);
		System.out.println(customerAddressRepository.saveAndFlush(customerAddress));
		return "Successfully Saved Address with New Address- "+customerAddressDTO.getAddress();
	}

	public String validate(@Valid CustomerIdentityDTO customerIdentityDTO) {
		Optional<CustomerIdentity> customerIdentityOptional=customerIdentityRepository.findById(customerIdentityDTO.getUniqueIdNumber());
		try {
			CustomerIdentity customerIdentity=customerIdentityOptional.orElseThrow();
			if(customerIdentity.getFirstName().equals(customerIdentityDTO.getFirstName()) && customerIdentity.getLastName().equals(customerIdentityDTO.getLastName())) {
				if(customerIdentity.getDateOfBirth().equals(customerIdentityDTO.getDateOfBirth())) {
					return activateSim(customerIdentityDTO);
				}
				else {
					return "Incorrect date of birth details";
				}
			}
			else {
				return "Invalid details";
			}
		}
		catch(NoSuchElementException ex) {
			return "Invalid Unique Number!";
		}
	}
	
	private String activateSim(CustomerIdentityDTO customerIdentityDTO) {
		Optional<Customer> customerOptional=customerRepository.findById(customerIdentityDTO.getUniqueIdNumber());
		try {
			Customer customer=customerOptional.orElseThrow();
			return simService.activateSim(customer.getSimId());
		}
		catch(NoSuchElementException ex) {
			return "Customer with given Unique Number not present in Customer Table!";
		}
	}

}
