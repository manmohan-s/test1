package com.infycom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infycom.entity.SimDetails;

public interface SimDetailsRepository extends JpaRepository<SimDetails,Integer> {

}
