package com.infycom.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.infycom.entity.SimOffers;

public interface SimOffersRepository  extends JpaRepository<SimOffers,Integer> {

}
