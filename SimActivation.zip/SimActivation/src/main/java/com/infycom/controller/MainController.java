package com.infycom.controller;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infycom.dto.CustomerAddressDTO;
import com.infycom.dto.CustomerDTO;
import com.infycom.dto.CustomerIdentityDTO;
import com.infycom.dto.SimOffersDTO;
import com.infycom.exceptions.InvalidEmailException;
import com.infycom.exceptions.NoSuchSimException;
import com.infycom.exceptions.SimAlreadyActiveException;
import com.infycom.service.CustomerService;
import com.infycom.service.SimService;


@RestController
@RequestMapping("/sap")
@Validated
public class MainController {
	@Autowired
	SimService simService;
	
	@Autowired
	CustomerService customerService;

	/*
	@PostMapping
	public String getOffer(
			@RequestParam("simNum") @Pattern(regexp="[0-9]{13}", message="Invalid details, please check again SIM number/Service number!") long simNum, 
			@RequestParam("serviceNum") @Pattern(regexp="[0-9]{10}", message="Invalid details, please check again SIM number/Service number!") long serviceNum){
		System.out.println(simNum+" "+serviceNum);
		return "Success";
	}
	*/
	
	@PostMapping(value = "/offer/{simNum}/{serviceNum}")
	public SimOffersDTO getOffer(
			@PathVariable("simNum") @Pattern(regexp="[0-9]{13}", message="Invalid details, please check again SIM number!") String simNum,
			@PathVariable("serviceNum") @Pattern(regexp="[0-9]{10}", message="Invalid details, please check again Service number!") String serviceNum) throws SimAlreadyActiveException, NoSuchSimException 
	{
		//System.out.println(simNum+" "+serviceNum);
		return simService.getOffer(simNum, serviceNum);
		
	}
	
	@PostMapping(value="/verify_basic")
	public String verifyBasicDetails(@Valid @RequestBody CustomerDTO customerDTO,Errors errors) 
	//Validation for this method is handled by CustomerDTO
	{
		return customerService.verifyBasicDetails(customerDTO);
	}
	
	
	@PostMapping(value="/verify_personal")
	public String verifyBasicDetails(@RequestBody CustomerDTO customerDTO) throws InvalidEmailException 
	//Validation for this method is handled by CustomerService
	{
		return customerService.verifyPersonalDetails(customerDTO);
	}
	
	@PutMapping(value="/update_address")
	public String updateAddress(@Valid @RequestBody CustomerAddressDTO customerAddressDTO)
	//Validation for this method is handled by CustomerAddressDTO
	{
		System.out.println(customerAddressDTO);
		return customerService.updateAdress(customerAddressDTO);
	}
	
	@PostMapping(value="/validate")
	public String validate(@Valid @RequestBody CustomerIdentityDTO customerIdentityDTO) {
	//Basic Input Validation handled by CustomerIdentityDTO, further exception and checking handled by CustomerService
		return customerService.validate(customerIdentityDTO);
	}
	
	
}
