package com.infycom.exceptions;

public class SimAlreadyActiveException extends Exception{
	public SimAlreadyActiveException(String message){
		super(message);
	}
	public SimAlreadyActiveException(){
	}
}
