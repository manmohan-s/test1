package com.infycom.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.infycom.entity.Customer;

public class CustomerDTO {
	private long uniqueIdNumber;
	@NotNull(message="DOB value is required!")
	@Pattern(regexp="[0-9]{4}-[0-9]{2}-[0-9]{2}", message= "Invalid Date of Birth!")
	private String dateOfBirth;
	@NotNull(message="Email value is required")
	@Pattern(regexp="^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}$", message= "Invalid Email!")
	private String emailAddress;
	//@NotNull(message="FirstName is required!")
	//@Pattern(regexp="[A-Za-z]{1,15}", message= "First Name length should be between 1-15!")
	private String firstName;
	//@NotNull(message="LastName is required!")
	//@Pattern(regexp="[A-Za-z]{1,15}", message= "First Name length should be between 1-15!")
	private String lastName;
	private String idType;
	private int customerAddress_addressId;
	private int simId;
	private String state;
	@Override
	public String toString() {
		return "CustomerDTO [uniqueIdNumber=" + uniqueIdNumber + ", dateOfBirth=" + dateOfBirth + ", emailAddress="
				+ emailAddress + ", firstName=" + firstName + ", lastName=" + lastName + ", idType=" + idType
				+ ", customerAddress_addressId=" + customerAddress_addressId + ", simId=" + simId + ", state=" + state
				+ "]";
	}
	public CustomerDTO() {
		super();
	}
	public CustomerDTO(long uniqueIdNumber, String dateOfBirth, String emailAddress, String firstName, String lastName,
			String idType, int customerAddress_addressId, int simId, String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.emailAddress = emailAddress;
		this.firstName = firstName;
		this.lastName = lastName;
		this.idType = idType;
		this.customerAddress_addressId = customerAddress_addressId;
		this.simId = simId;
		this.state = state;
	}
	public long getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(long uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getIdType() {
		return idType;
	}
	public void setIdType(String idType) {
		this.idType = idType;
	}
	public int getCustomerAddress_addressId() {
		return customerAddress_addressId;
	}
	public void setCustomerAddress_addressId(int customerAddress_addressId) {
		this.customerAddress_addressId = customerAddress_addressId;
	}
	public int getSimId() {
		return simId;
	}
	public void setSimId(int simId) {
		this.simId = simId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public static CustomerDTO prepareDTO(Customer customer) {
		CustomerDTO customerDTO=new CustomerDTO();
		customerDTO.setDateOfBirth(customer.getDateOfBirth());
		customerDTO.setEmailAddress(customer.getEmailAddress());
		customerDTO.setFirstName(customer.getFirstName());
		customerDTO.setLastName(customer.getLastName());
		customerDTO.setIdType(customer.getIdType());
		customerDTO.setSimId(customer.getSimId());
		customerDTO.setState(customer.getState());
		customerDTO.setUniqueIdNumber(customer.getUniqueIdNumber());
		
		return customerDTO;
	}
	
	public static Customer prepareEntity(CustomerDTO customerDTO) {
		Customer customer=new Customer();
		customer.setDateOfBirth(customerDTO.getDateOfBirth());
		customer.setEmailAddress(customerDTO.getEmailAddress());
		customer.setFirstName(customerDTO.getFirstName());
		customer.setLastName(customerDTO.getLastName());
		customer.setIdType(customerDTO.getIdType());
		customer.setSimId(customerDTO.getSimId());
		customer.setState(customerDTO.getState());
		customer.setUniqueIdNumber(customerDTO.getUniqueIdNumber());
		return customer;
	}
}
