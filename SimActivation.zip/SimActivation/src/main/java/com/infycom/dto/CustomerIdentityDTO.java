package com.infycom.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Range;

import com.infycom.entity.CustomerIdentity;

public class CustomerIdentityDTO {
	@NotNull(message="UniqueIDNumber is required!")
	@Range(min=1000000000000000L, max=9999999999999999L, message="Id should be 16 digit!")
	private Long uniqueIdNumber;
	@NotNull(message="DOB value is required!")
	@Pattern(regexp="[0-9]{4}-[0-9]{2}-[0-9]{2}", message= "Invalid Date of Birth!")
	private String dateOfBirth;
	@NotNull(message="FirstName is required!")
	@Pattern(regexp="[A-Za-z]{1,15}", message= "FirstName should only be alphabets and length should be between 1-15!")
	private String firstName;
	@NotNull(message="LastName is required!")
	@Pattern(regexp="[A-Za-z]{1,15}", message= "LastName should only be alphabets and length should be between 1-15!")
	private String lastName;
	private String emailAddress;
	private String state;
	@Override
	public String toString() {
		return "CustomerIdentityDTO [uniqueIdNumber=" + uniqueIdNumber + ", dateOfBirth=" + dateOfBirth + ", firstName="
				+ firstName + ", lastName=" + lastName + ", emailAddress=" + emailAddress + ", state=" + state + "]";
	}
	public CustomerIdentityDTO() {
		super();
	}
	public CustomerIdentityDTO(long uniqueIdNumber, String dateOfBirth, String firstName, String lastName,
			String emailAddress, String state) {
		super();
		this.uniqueIdNumber = uniqueIdNumber;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.state = state;
	}
	public long getUniqueIdNumber() {
		return uniqueIdNumber;
	}
	public void setUniqueIdNumber(long uniqueIdNumber) {
		this.uniqueIdNumber = uniqueIdNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	public static CustomerIdentityDTO prepareDTO(CustomerIdentity customerIdentity) {
		CustomerIdentityDTO customerIdentityDTO=new CustomerIdentityDTO();
		customerIdentityDTO.setUniqueIdNumber(customerIdentity.getUniqueIdNumber());
		customerIdentityDTO.setDateOfBirth(customerIdentity.getDateOfBirth());
		customerIdentityDTO.setFirstName(customerIdentity.getFirstName());
		customerIdentityDTO.setLastName(customerIdentity.getLastName());
		customerIdentityDTO.setEmailAddress(customerIdentity.getEmailAddress());
		customerIdentityDTO.setState(customerIdentity.getState());
		return customerIdentityDTO;
	}
	
	public static CustomerIdentity prepareEntity(CustomerIdentityDTO customerIdentityDTO) {
		CustomerIdentity customerIdentity=new CustomerIdentity();
		customerIdentity.setUniqueIdNumber(customerIdentityDTO.getUniqueIdNumber());
		customerIdentity.setDateOfBirth(customerIdentityDTO.getDateOfBirth());
		customerIdentity.setFirstName(customerIdentityDTO.getFirstName());
		customerIdentity.setLastName(customerIdentityDTO.getLastName());
		customerIdentity.setEmailAddress(customerIdentityDTO.getEmailAddress());
		customerIdentity.setState(customerIdentityDTO.getState());
		return customerIdentity;
	}

}
