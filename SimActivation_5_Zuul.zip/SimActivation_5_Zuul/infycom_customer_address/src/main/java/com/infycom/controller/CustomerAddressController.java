package com.infycom.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infycom.dto.CustomerAddressDTO;
import com.infycom.service.CustomerAddressService;

@RestController
@RequestMapping("/sap")
@Validated
public class CustomerAddressController {
	
	@Autowired
	CustomerAddressService customerAddressService;
	
	@PutMapping(value="/update_address")
	public String updateAddress(@Valid @RequestBody CustomerAddressDTO customerAddressDTO)
	//Validation for this method is handled by CustomerAddressDTO
	{
		System.out.println(customerAddressDTO);
		return customerAddressService.updateAdress(customerAddressDTO);
	}
	
	@GetMapping(value="/address/{addressID}")
	public CustomerAddressDTO getAddress(@PathVariable("addressID") int addressID) {
		System.out.println("XXXXX --- Fethcing Data");
		return customerAddressService.getAddress(addressID);
	}
	

}
