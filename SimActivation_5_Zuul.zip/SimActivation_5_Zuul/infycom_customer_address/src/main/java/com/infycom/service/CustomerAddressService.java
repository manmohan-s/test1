package com.infycom.service;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infycom.dto.CustomerAddressDTO;
import com.infycom.entity.CustomerAddress;
import com.infycom.repository.CustomerAddressRepository;

@Service
public class CustomerAddressService {
	
	@Autowired
	CustomerAddressRepository customerAddressRepository;
	
	public String updateAdress(@Valid CustomerAddressDTO customerAddressDTO) {
		CustomerAddress customerAddress=CustomerAddressDTO.prepareEntity(customerAddressDTO);
		System.out.println(customerAddressRepository.saveAndFlush(customerAddress));
		return "Successfully Saved Address with New Address- "+customerAddressDTO.getAddress();
	}
	
	public CustomerAddressDTO getAddress(int addressID) {
		Optional<CustomerAddress> custAddrOpt=customerAddressRepository.findById(addressID);
		CustomerAddress customerAddress=custAddrOpt.orElse(new CustomerAddress());
		CustomerAddressDTO customerAddressDTO=CustomerAddressDTO.prepareDTO(customerAddress);
		if(customerAddressDTO.getAddress()==null) {
			customerAddressDTO.setAddress("Invalid Address ID");
		}
		return customerAddressDTO;		
	}

}
