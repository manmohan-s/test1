package com.infycom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infycom.entity.CustomerAddress;


public interface CustomerAddressRepository extends JpaRepository<CustomerAddress,Integer> {

}
