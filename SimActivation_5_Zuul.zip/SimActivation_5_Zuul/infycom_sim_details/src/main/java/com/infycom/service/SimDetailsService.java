package com.infycom.service;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infycom.dto.SimDetailsDTO;
import com.infycom.dto.SimDetailsList;
import com.infycom.entity.SimDetails;
import com.infycom.repository.SimDetailsRepository;

@Service
public class SimDetailsService {
	@Autowired
	SimDetailsRepository simDetailsRepository;
	
	public SimDetailsList getAllSims(){
		List<SimDetails> list_sim=simDetailsRepository.findAll();
		
		List<SimDetailsDTO> list_sims_dto=new ArrayList<SimDetailsDTO>();
		SimDetailsList list_sim_obj=new SimDetailsList();
		for(SimDetails sim:list_sim) {
			list_sim_obj.getList_sim_dtos().add(SimDetailsDTO.prepareDTO(sim));
		}
		return list_sim_obj;
		
	}
	
	public String activateSim(int simId) {
		Optional<SimDetails> simDetailsOptional=simDetailsRepository.findById(simId);
		System.out.println(simId+" simID");
		try {
			SimDetails simDetails=simDetailsOptional.orElseThrow();
			simDetails.setSimStatus("active");
			simDetailsRepository.saveAndFlush(simDetails);
			return "SIM succussfully activated";
		}
		catch(NoSuchElementException ex) {
			return "SimDetails with given simId not present in SimDetails Table!";
		}
	}
}
