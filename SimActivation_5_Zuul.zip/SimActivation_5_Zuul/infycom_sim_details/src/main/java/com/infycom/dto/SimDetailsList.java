package com.infycom.dto;

import java.util.ArrayList;
import java.util.List;

public class SimDetailsList {
	private List<SimDetailsDTO> list_sim_dtos;

	public SimDetailsList() {
		list_sim_dtos=new ArrayList<>();
		
	}

	public List<SimDetailsDTO> getList_sim_dtos() {
		return list_sim_dtos;
	}

	public void setList_sim_dtos(List<SimDetailsDTO> list_sim_dtos) {
		this.list_sim_dtos = list_sim_dtos;
	}
	
	
}
