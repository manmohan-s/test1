package com.infycom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfycomSimOffersApplicationTests {

	@Test
	void contextLoads() {
	}

}
