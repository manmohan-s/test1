package com.infycom.controller;

import javax.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infycom.dto.SimOffersDTO;
import com.infycom.exceptions.NoSuchSimException;
import com.infycom.exceptions.SimAlreadyActiveException;
import com.infycom.service.SimOffersService;

@RestController
@RequestMapping("/sap")
@Validated
public class SimOffersController {
	@Autowired
	SimOffersService simOffersService;
	
	@PostMapping(value = "/offer/{simNum}/{serviceNum}")
	public SimOffersDTO getOffer(
			@PathVariable("simNum") @Pattern(regexp="[0-9]{13}", message="Invalid details, please check again SIM number!") String simNum,
			@PathVariable("serviceNum") @Pattern(regexp="[0-9]{10}", message="Invalid details, please check again Service number!") String serviceNum) throws SimAlreadyActiveException, NoSuchSimException 
	{
		System.out.println(simNum+" "+serviceNum);
		
		return simOffersService.getOffer(simNum, serviceNum);
		
	}
}
