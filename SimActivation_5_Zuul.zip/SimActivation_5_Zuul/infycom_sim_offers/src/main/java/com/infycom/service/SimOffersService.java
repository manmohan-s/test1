package com.infycom.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infycom.dto.SimDetailsDTO;
import com.infycom.dto.SimDetailsList;
import com.infycom.dto.SimOffersDTO;
import com.infycom.entity.SimOffers;
import com.infycom.exceptions.NoSuchSimException;
import com.infycom.exceptions.SimAlreadyActiveException;
import com.infycom.repository.SimOffersRepository;

@Service
public class SimOffersService {
	
	@Autowired
	SimOffersRepository simOffersRepository;
	
	@Value("${simdetails.uri}")
	String sim_details_uri;
	
	
	public SimOffersDTO getOffer(String simNum1, String serviceNum1) throws SimAlreadyActiveException, NoSuchSimException {
		long simNum=Long.parseLong(simNum1);
		long serviceNum=Long.parseLong(serviceNum1);
		//System.out.println("XXX - In service");
		//System.out.println(sim_offers_uri);
		SimDetailsList list_sims_wrapper=new RestTemplate().getForObject(sim_details_uri+"/sims", SimDetailsList.class);
		SimOffersDTO simOffersDTO=null;
		List<SimDetailsDTO> list_sim=list_sims_wrapper.getList_sim_dtos();
		for(SimDetailsDTO sim:list_sim) {
			//System.out.println(sim.getServiceNumber());
			if(sim.getSimNumber()==simNum && sim.getServiceNumber()==serviceNum) {
				if(sim.getSimStatus().equals("active")) {
					throw new SimAlreadyActiveException();
				}
				List<SimOffers> list_offer=simOffersRepository.findAll();
				for (SimOffers simOfferTemp : list_offer) {
					if(sim.getSimId()==simOfferTemp.getSimId()) {
						simOffersDTO=SimOffersDTO.prepareDTO(simOfferTemp);
					}
				}
				
			}
		}
		if(simOffersDTO==null) {
			throw new NoSuchSimException();
		}
		else {
			return simOffersDTO;
		}	
	}
	
}
