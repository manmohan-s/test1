package com.infycom.service;

import java.util.NoSuchElementException;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infycom.dto.CustomerIdentityDTO;
import com.infycom.entity.CustomerIdentity;
import com.infycom.repository.CustomerIdentityRepository;

@Service
public class CustomerIdentityService {
	@Autowired
	CustomerIdentityRepository customerIdentityRepository;
	
	@Value("${customer.uri}")
	String customer_uri;
	@Value("${sim_detail.uri}")
	String sim_details_uri;
	
	public String validate(@Valid CustomerIdentityDTO customerIdentityDTO) {
		Optional<CustomerIdentity> customerIdentityOptional=customerIdentityRepository.findById(customerIdentityDTO.getUniqueIdNumber());
		try {
			CustomerIdentity customerIdentity=customerIdentityOptional.orElseThrow();
			if(customerIdentity.getFirstName().equals(customerIdentityDTO.getFirstName()) && customerIdentity.getLastName().equals(customerIdentityDTO.getLastName())) {
				if(customerIdentity.getDateOfBirth().equals(customerIdentityDTO.getDateOfBirth())) {
					return activateSim(customerIdentityDTO);
				}
				else {
					return "Incorrect date of birth details";
				}
			}
			else {
				return "Invalid details";
			}
		}
		catch(NoSuchElementException ex) {
			return "Invalid Unique Number!";
		}
	}
	
	
	//TODO: Complete this
	private String activateSim(CustomerIdentityDTO customerIdentityDTO) {
		/*
		Optional<Customer> customerOptional=customerRepository.findById(customerIdentityDTO.getUniqueIdNumber());
		try {
			Customer customer=customerOptional.orElseThrow();
			return simService.activateSim(customer.getSimId());
		}
		catch(NoSuchElementException ex) {
			return "Customer with given Unique Number not present in Customer Table!";
		}
		*/
		Integer simID=new RestTemplate().getForObject(customer_uri+"/getsimid/"+customerIdentityDTO.getUniqueIdNumber(), Integer.class);
		System.out.println("SIMID "+simID);
		if(simID==-1) {
			return "Customer with given Unique Number not present in Customer Table!";
		}
		else {
			String res=new RestTemplate().getForObject(sim_details_uri+"/activate/"+simID, String.class);
			return res;
		}
		//
	}
	
}
