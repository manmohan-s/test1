package com.infycom.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infycom.dto.CustomerIdentityDTO;
import com.infycom.service.CustomerIdentityService;

@RestController
@RequestMapping("/sap")
@Validated
public class CustomerIdentityController {
	@Autowired
	CustomerIdentityService customerIdentityService;

	@PostMapping(value="/validate")
	public String validate(@Valid @RequestBody CustomerIdentityDTO customerIdentityDTO) {
	//Basic Input Validation handled by CustomerIdentityDTO, further exception and checking handled by CustomerService
		return customerIdentityService.validate(customerIdentityDTO);
	}
}
