package com.infycom.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infycom.entity.CustomerIdentity;

public interface CustomerIdentityRepository extends JpaRepository<CustomerIdentity,Long>{

}
