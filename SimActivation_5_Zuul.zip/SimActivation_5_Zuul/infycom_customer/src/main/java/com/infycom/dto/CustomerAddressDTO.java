package com.infycom.dto;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


public class CustomerAddressDTO {
	@NotNull(message="Address ID is mandatory! ")
	private Integer addressId;
	@Size(min=1,max=25, message = "Address should be of minimum 1 and maximum of 25 characters! ") 
	private String address;
	@Pattern(regexp="[A-Za-z ]+", message="City should not contain any special characters except space! ")
	private String city;
	//@Pattern(regexp="[0-9]{6}", message="Pin should be 6 digit number! ")
	@Min(value=100000, message="Pin should be 6 digit number! ")
	@Digits(integer=6, fraction = 0,message="Pin should be 6 digit number! ")
	private int pincode;
	@Pattern(regexp="[A-Za-z ]+", message="State should not contain any special characters except space! ")
	private String state;
	@Override
	public String toString() {
		return "CustomerAddressDTO [addressId=" + addressId + ", address=" + address + ", city=" + city + ", pincode="
				+ pincode + ", state=" + state + "]";
	}
	public CustomerAddressDTO() {
		super();
	}
	public CustomerAddressDTO(int addressId, String address, String city, int pincode, String state) {
		super();
		this.addressId = addressId;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	/*
	public static CustomerAddressDTO prepareDTO(CustomerAddress customerAddress) {
		CustomerAddressDTO customerAddressDTO=new CustomerAddressDTO();
		customerAddressDTO.setAddressId(customerAddress.getAddressId());
		customerAddressDTO.setAddress(customerAddress.getAddress());
		customerAddressDTO.setCity(customerAddress.getCity());
		customerAddressDTO.setPincode(customerAddress.getPincode());
		customerAddressDTO.setState(customerAddress.getState());
		return customerAddressDTO;
	}
	
	public static CustomerAddress prepareEntity(CustomerAddressDTO customerAddressDTO) {
		CustomerAddress customerAddress=new CustomerAddress();
		customerAddress.setAddressId(customerAddressDTO.getAddressId());
		customerAddress.setAddress(customerAddressDTO.getAddress());
		customerAddress.setCity(customerAddressDTO.getCity());
		customerAddress.setPincode(customerAddressDTO.getPincode());
		customerAddress.setState(customerAddressDTO.getState());
		return customerAddress;
	}
	*/

}
