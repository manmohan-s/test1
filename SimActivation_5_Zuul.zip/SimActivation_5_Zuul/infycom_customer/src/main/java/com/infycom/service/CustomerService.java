package com.infycom.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.infycom.dto.CustomerAddressDTO;
import com.infycom.dto.CustomerDTO;
import com.infycom.entity.Customer;
import com.infycom.exceptions.InvalidEmailException;
import com.infycom.repository.CustomerRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
//@RibbonClient(name="addressRibbon") //only for ribbon
public class CustomerService {
	@Autowired
	CustomerRepository customerRepository;
	
	//@Autowired
	//DiscoveryClient client;
	//For Discovery through Eureka (only Eureka, not needed for ribbon+Eureka)
	
	@Autowired
	RestTemplate restTemplate;
	//For Ribbon and Ribbon+Eureka
	
	@Value("${address.uri}")
	String address_uri;
	
	@HystrixCommand(fallbackMethod = "getProfilebyUIDFallback")
	public CustomerDTO getProfilebyUID(long uid) {
		Optional<Customer> custOpt=customerRepository.findById(uid);
		Customer customer=custOpt.orElse(new Customer());
		CustomerDTO customerDTO=CustomerDTO.prepareDTO(customer);
		//if(uid==1234567891234567L) {
		//	throw new RuntimeException();
		//}
		if(customerDTO.getUniqueIdNumber()==0) {
			customerDTO.setFirstName("No such Customer Found, Check UID");
			customerDTO.setLastName("No such Customer Found, Check UID");
		}
		else {
			System.out.println("XXXXXXX -- Requesting Address");
			
			/*
			//Using just Eureka
			List<ServiceInstance> instances=client.getInstances("CustomerAddressMS");
			ServiceInstance instance=instances.get(0);
			URI addr_uri=instance.getUri();
			CustomerAddressDTO customerAddressDTO=new RestTemplate().getForObject(addr_uri+"/sap/address/"+customerDTO.getCustomerAddress_addressId(), CustomerAddressDTO.class);
			*/
			
			//CustomerAddressDTO customerAddressDTO=restTemplate.getForObject("http://addressRibbon/sap/address/"+customerDTO.getCustomerAddress_addressId(), CustomerAddressDTO.class);
			//Using just Ribbon
			
			CustomerAddressDTO customerAddressDTO=restTemplate.getForObject("http://CustomerAddressMS/sap/address/"+customerDTO.getCustomerAddress_addressId(), CustomerAddressDTO.class);
			
			System.out.println(customerDTO.getCustomerAddress_addressId());
			System.out.println(customerAddressDTO);
			customerDTO.setCustomerAddressDTO(customerAddressDTO);
		}
		return customerDTO;
		

	}
	
	public CustomerDTO getProfilebyUIDFallback(long uid) {
		CustomerDTO customerDTO=new CustomerDTO();
		customerDTO.setFirstName("Something went wrong!");
		return customerDTO;
	}

	public Integer getSimID(long uid) {
		// TODO Auto-generated method stub
		Optional<Customer> customerOptional=customerRepository.findById(uid);
		try {
			Customer customer=customerOptional.orElseThrow();
			return customer.getSimId();
		}
		catch(NoSuchElementException ex) {
			return -1;
		}
		//return -1;
	}
	
	public String verifyBasicDetails(CustomerDTO customerDTO) {
		String email=customerDTO.getEmailAddress();
		String dob=customerDTO.getDateOfBirth();
		List<Customer> list_customer=customerRepository.findAll();
		for (Customer customer : list_customer) {
			if(customer.getEmailAddress().equals(email) && customer.getDateOfBirth().equals(dob)) {
				return "Successfully verified";
			}
		}
		return "No request placed for you";
	}
	
	public String verifyPersonalDetails(CustomerDTO customerDTO) throws InvalidEmailException {
		String error="";
		String fname=customerDTO.getFirstName();
		String lname=customerDTO.getLastName();
		if(fname==null) {
			error+="FirstName is required! ";
		}
		else {
			if(! fname.matches("[A-Za-z]{1,15}")){
				error+="FirstName should only be alphabets with length of 1-15 character! ";
			}
		}
		if(lname==null) {
			error+="LastName is required! ";
		}
		else {
			if(! lname.matches("[A-Za-z]{1,15}")){
				error+="LastName should only be alphabets with length of 1-15 character! ";
			}
		}
		
		if(error!="") {
			return error;
		}
		String email=customerDTO.getEmailAddress();
		List<Customer> list_customer=customerRepository.findAll();
		for (Customer customer : list_customer) {
			if(customer.getFirstName().equals(fname) && customer.getLastName().equals(lname)) {
				if(customer.getEmailAddress().equals(email)) {
					return "Successfully verified";
				}
				else {
					throw new InvalidEmailException();
				}
			}
		}
		return "No customer found for the provided details";
	}

}
