package com.infycom.exceptions;

import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.infycom.dto.ErrorMessage;

@RestControllerAdvice
public class ExceptionControllerAdvice {
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(Exception ex){
		ErrorMessage error= new ErrorMessage();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		//error.setMessage(ex.getMessage());
		System.out.println(ex.getMessage());
		error.setMessage("Something went wrong. We're on it.");
		return new ResponseEntity<>(error,HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(SimAlreadyActiveException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(SimAlreadyActiveException ex){
		ErrorMessage error= new ErrorMessage();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("Sim is already active!");
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	
	@ExceptionHandler(NoSuchSimException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(NoSuchSimException ex){
		ErrorMessage error= new ErrorMessage();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("Invalid details, please check again SIM number/Service number!");
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	@ExceptionHandler(InvalidEmailException.class)
	public ResponseEntity<ErrorMessage> exceptionHandler(InvalidEmailException ex){
		ErrorMessage error= new ErrorMessage();
		error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
		error.setMessage("Invalid email details!");
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<ErrorMessage> handleConstraintValidationExceptions(ConstraintViolationException ex) 
	{
		 ErrorMessage error = new ErrorMessage();
	     error.setErrorCode(HttpStatus.BAD_REQUEST.value());
	     //System.out.println("Here Finally");
	     error.setMessage(ex.getConstraintViolations()
	    		 			.stream().map(ConstraintViolation::getMessage)
	    		 			.collect(Collectors.joining(", ")));
	    
	     return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> handleValidationExceptions(MethodArgumentNotValidException ex) 
	{
		 ErrorMessage error = new ErrorMessage();
		 System.out.println("In method exc");
	     error.setErrorCode(HttpStatus.BAD_REQUEST.value());
	     error.setMessage(ex.getBindingResult().getAllErrors()
	    		 		  	.stream().map(ObjectError::getDefaultMessage)
	    		 		  	.collect(Collectors.joining(", ")));
	     return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}
	
		
}


/*
@ExceptionHandler(ConstraintViolationException.class)
public ResponseEntity<ErrorMessage> handleConstraintValidationExceptions(ConstraintViolationException ex){
	ErrorMessage error= new ErrorMessage();
	error.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
	//error.setMessage(ex.getMessage());
	error.setMessage("test");
	return new ResponseEntity<>(error,HttpStatus.OK);
}
*/
