package com.infycom.exceptions;

public class NoSuchSimException extends Exception{
	public NoSuchSimException(String message){
		super(message);
	}
	public NoSuchSimException(){
	}
}
